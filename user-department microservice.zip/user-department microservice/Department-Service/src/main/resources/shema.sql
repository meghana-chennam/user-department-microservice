create table department(
deptId integer not null auto_increment primary key,
deptName varchar(30),
deptAddress varchar(100),
deptCode varchar(30)
);


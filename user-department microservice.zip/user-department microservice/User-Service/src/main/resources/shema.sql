create table user(
userId integer not null auto_increment primary key,
firstName varchar(30),
lastName varchar(30),
deptId integer,
userEmail varchar(30)
);
